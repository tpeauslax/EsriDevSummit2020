# EsriDevSummit2020
This folder Dev2020 contains all the slides, data, tools, and scripts for ESRI 2020 dev-summit session "Consuming and Using Web Tools and Geoprocessing Services" (Using python). 
