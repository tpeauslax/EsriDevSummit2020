portalname = 'portal_name'
fedservername = 'federatedserver_name'
username = 'portal_username'
password = 'portal_password'

standaloneserver = 'standaloneserver_name'
sausername = "standaloneserver_username"
sapassword = "standaloneserver_password"

uncpath = r"uncpath"
