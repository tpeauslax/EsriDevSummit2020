This folder Dev2020 contains all the data, tools, and scripts for ESRI 2020 dev-summit session "Consuming and Using Web Tools and Geoprocessing Services" (Using python). 


1. Copy and paste the folder to your local drive. 

2. Publishing and running script are in Script folder. Modify the workspace of each script. 

3. Configure all the information of portal, servers, credentials, and unc path avaialbe to you in Script/config.py. 

4. Provide a server connection file (.ags file with admin account) in Data/Connection folder if you want to publsih and run gp service. 

5. You are ready to run all the publishing and consuming scripts. 